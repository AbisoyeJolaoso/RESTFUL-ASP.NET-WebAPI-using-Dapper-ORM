$(document).ready(function() {
					   $('#submit').click(function() 
					   {
					       if ($('#Name').val() == "" || $('#Hospital').val()=="" || $('#Age').val() == "" || $('#Address').val()== "")
					           {
					               return false;
					           }
					      else {
					           $.ajax({
					               type: "POST",
					               url: 'http://localhost:7251/api/Patients',
					               crossDomain: true,
					               async: true,
					               data: {
					                   PatientId: 0,
					                   Name: $('#Name').val(),
					                   Hospital: $('#Hospital').val(),
					                   Age: $('#Age').val(),
					                   Address: $('#Address').val()
					               },
					               cache: false,
					               dataType: "json",
					               success: function (response) {
					                   alert(response);
					                   //if (response.status == 200) { alert(response.status); }
					                   //else { alert(response.response); }
					                   //window.location = 'http://localhost:7251';
					                   //return false
					                       }
					                   });
    					       }
					   });
				  });	

		$(document).ajaxError(function (event, request, settings, thrownError) {
				    alert('Error occured: ' + thrownError);
				    //$('.ui-loader').hide(); //hide loader
				    return false;
				});
				