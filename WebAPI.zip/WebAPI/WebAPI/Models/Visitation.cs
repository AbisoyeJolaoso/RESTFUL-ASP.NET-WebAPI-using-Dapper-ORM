﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPI.Models
{
    public class Visitation
    {
        public int PatientsId { get; set; }
        public DateTime EncounterDate { get; set; }
        public string DoctorName { get; set; }
        public string MedicalRecord { get; set; }
    }
}