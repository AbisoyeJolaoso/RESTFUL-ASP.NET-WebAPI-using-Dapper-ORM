﻿using System.Collections.Generic;

namespace WebAPI.Dao
{
    public interface IDapperDao
    {
        List<T> ExecuteQuery<T>(string query, object paramList = null);
        T ExecuteProcedure<T>(string procedureName, object paramList = null);
    }
}