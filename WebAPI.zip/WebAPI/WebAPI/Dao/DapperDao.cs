﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using System.Data;


namespace WebAPI.Dao
{

    public class DapperDao : IDapperDao
    {      
        public List<T> ExecuteQuery<T>(string query, object paramList = null)
        {
            try
            {
                using (var db = new SqlConnection(ConnectionString))
                {
                    return db.Query<T>(query, paramList).ToList();
                }
            }
            catch{
               return new List<T>();
            }
        }

        public T ExecuteProcedure<T>(string procedureName, object paramList = null)
        {
            try
            {
                using (var db = new SqlConnection(ConnectionString))
                {
                 return db.QueryFirstOrDefault<T>(procedureName, paramList, commandType: CommandType.StoredProcedure);
                }
            }
            catch{
                return default(T);
            }
        }
        public string ConnectionString { get { return @"Data Source=ISW-IFT-AA2;Initial Catalog=Demo;Integrated Security=True"; } } 
    }
}