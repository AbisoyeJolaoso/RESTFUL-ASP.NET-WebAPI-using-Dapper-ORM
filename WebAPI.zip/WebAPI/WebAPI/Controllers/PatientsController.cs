﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Models;
using System.Data.SqlClient;
using Dapper;
using WebAPI.Dao;

namespace WebAPI.Controllers
{
    public class PatientsController : ApiController
    {

        private IDapperDao _dao;

        public PatientsController()
        {
            _dao = new DapperDao();
        }

        public PatientsController(IDapperDao dao)
        {
            _dao = dao;
        }  

        [HttpPost]
        public IHttpActionResult Post([FromBody]Patients patients)
        {
            try
            {
                _dao.ExecuteQuery<Patients>("INSERT INTO Patients(Name,Hospital,Age,Address) Values (@Name,@Hospital,@Age,@Address)",
                    new { Name = patients.Name, Hospital = patients.Hospital, Age = patients.Age, Address = patients.Address});
                
                return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        public List<Patients> Get()
        {
            return _dao.ExecuteQuery<Patients>("Select * From Patients");
        }

        public Patients Get(int id)
        {
            return _dao.ExecuteQuery<Patients>("Select * From Patients WHERE PatientsId = @id", new { id }).FirstOrDefault();
        }

        [ActionName("DeletePatients")]
        public void DeleteEmployeeByID(int id)
        {
            _dao.ExecuteQuery<Patients>("delete from Patients where PatientsId = @id", new { id });
        }

       
       

    }
}
