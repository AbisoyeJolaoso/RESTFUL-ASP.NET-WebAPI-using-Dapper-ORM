﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Models;
using System.Data.SqlClient;
using Dapper;
using WebAPI.Dao;

namespace WebAPI.Controllers
{
    public class VisitationController : ApiController

    {
        private IDapperDao _dao;

        public VisitationController()
        {
            _dao = new DapperDao();
        }

        public VisitationController(IDapperDao dao)
        {
            _dao = dao;
        }
        [HttpPost]
        public IHttpActionResult Post([FromBody]Visitation visitation)
        {
            try
            {
             
            _dao.ExecuteQuery<Visitation>(@"INSERT INTO Visitation(PatientsId,EncounterDate,DoctorName,MedicalRecord) 
                                            Values (@PatientsId,@EncounterDate,@DoctorName,@MedicalRecord)",
                new { PatientsId = visitation.PatientsId, EncounterDate = visitation.EncounterDate, DoctorName = visitation.DoctorName, MedicalRecord=visitation.MedicalRecord });
            return Ok();
            }
            catch
            {
                return BadRequest();
            }
        }

        public List<Visitation> Get()
        {
            return _dao.ExecuteQuery<Visitation>("Select * From Visitation");
        }

        public Visitation Get(int id)
        {
            return _dao.ExecuteQuery<Visitation>("Select * From Visitation WHERE PatientsId = @id", new { id }).FirstOrDefault();
        }
        
        [ActionName("DeleteVisitation")]
        public void DeleteEmployeeByID(int id)
        {
            _dao.ExecuteQuery<Visitation>("delete from Visitation where PatientsId = @id", new { id });

        }



    }
}
